import styled from 'styled-components';

export type Props = {
  // ...
};

export const Button = styled.button<Props>``;

export default Button;